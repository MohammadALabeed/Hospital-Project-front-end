---
name: Clinical Precision
colors:
  surface: '#f8f9fb'
  surface-dim: '#d9dadc'
  surface-bright: '#f8f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f6'
  surface-container: '#edeef0'
  surface-container-high: '#e7e8ea'
  surface-container-highest: '#e1e2e4'
  on-surface: '#191c1e'
  on-surface-variant: '#444651'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f3'
  outline: '#757682'
  outline-variant: '#c5c5d3'
  surface-tint: '#4059aa'
  primary: '#00236f'
  on-primary: '#ffffff'
  primary-container: '#1e3a8a'
  on-primary-container: '#90a8ff'
  inverse-primary: '#b6c4ff'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#00311f'
  on-tertiary: '#ffffff'
  tertiary-container: '#004a31'
  on-tertiary-container: '#27c38a'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b6c4ff'
  on-primary-fixed: '#00164e'
  on-primary-fixed-variant: '#264191'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f8f9fb'
  on-background: '#191c1e'
  surface-variant: '#e1e2e4'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  data-mono:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max-width: 1440px
  gutter: 24px
  margin-desktop: 40px
  margin-mobile: 16px
---

## Brand & Style
The design system is engineered for high-stakes healthcare environments where clarity, speed of cognition, and a sense of absolute security are paramount. The brand personality is professional, authoritative, and meticulously organized.

The visual style follows a **Corporate / Modern** aesthetic, utilizing a systematic approach to density and whitespace. It prioritizes "information ergonomics"—ensuring that medical staff can distinguish between critical alerts and routine data at a glance. By combining a restrained color palette with high-fidelity UI elements, the system evokes a sense of modern medical excellence and technical reliability.

## Colors
The color strategy is anchored by **Deep Clinical Blue**, representing stability and medical authority. The primary background uses a **Clean Gray** to reduce eye strain during long shifts.

- **Primary (#1E3A8A):** Used for primary actions, active navigation states, and brand-identifiable elements.
- **Secondary (#64748B):** A muted slate used for supporting text, icons, and secondary interface elements.
- **Tertiary (#10B981):** Reserved for "Healthy" or "Success" states, such as stable vitals or completed tasks.
- **Neutral (#F3F4F6):** The foundation for the workspace, providing a clean canvas that separates functional modules.
- **Functional Colors:** Bold Red (#EF4444) is strictly for critical alerts and emergencies, while Amber (#F59E0B) indicates warnings or pending lab results.

## Typography
This design system utilizes **Inter** exclusively to leverage its exceptional legibility and systematic weight distribution. 

For data-heavy views, such as patient vitals and medical dosages, use the `data-mono` variant which enables tabular figures to ensure numbers align perfectly in tables. Headlines use tighter letter spacing for a more authoritative, modern look, while body text maintains standard spacing for maximum readability in medical reports.

## Layout & Spacing
The layout is built on a **12-column fluid grid** for desktop, optimized for wide-screen medical monitors. We use an **8px linear scale** for all spacing increments to ensure mathematical harmony across the UI.

- **Desktop:** 12 columns, 24px gutters, 40px side margins. 
- **Tablet:** 8 columns, 16px gutters, 24px side margins.
- **Mobile:** 4 columns, 16px gutters, 16px side margins.

Information density is "Medium-High." Critical data visualizations should prioritize breathing room, while administrative data tables can utilize a more compact row height (40px–48px) to maximize visible data points without scrolling.

## Elevation & Depth
Depth is conveyed through **Tonal Layers** and **Low-Contrast Outlines** rather than heavy shadows, maintaining a sterile and organized feel.

1.  **Level 0 (Base):** The #F3F4F6 background.
2.  **Level 1 (Cards/Surface):** Pure White (#FFFFFF) surfaces with a subtle 1px border (#E2E8F0).
3.  **Level 2 (Popovers/Dropdowns):** Pure White with a soft, diffused ambient shadow (0px 4px 12px rgba(0, 0, 0, 0.05)) to separate temporary UI from the data plane.
4.  **Level 3 (Modals):** Pure White with a stronger shadow and a 40% opacity backdrop blur to focus the user on critical clinical decisions.

## Shapes
The shape language uses a **Soft (1)** rounding logic. 

- **Components (Buttons, Inputs):** 0.25rem (4px) corner radius. This creates a professional, precise appearance that feels modern but remains grounded.
- **Containers (Cards, Modals):** 0.5rem (8px) corner radius for larger surfaces.
- **Status Indicators:** Pills (fully rounded) are used specifically for status tags (e.g., "Admitted," "Discharged") to differentiate them from interactive buttons.

## Components

### Buttons
- **Primary:** Solid #1E3A8A with white text. High-contrast, rectangular with soft 4px corners.
- **Secondary:** Outlined with a 1px border of #1E3A8A. Used for non-primary actions like "Export" or "Print."
- **Ghost:** No background or border. Used for tertiary actions within tables.

### Input Fields
- **Design:** White background with a 1px #D1D5DB border. 
- **Icons:** Leading icons (20px) are used to provide visual cues (e.g., a magnifying glass for search, a calendar for appointments).
- **Focus State:** 2px solid #1E3A8A ring with a subtle offset.

### Data Tables (Premium)
- **Header:** Light gray background (#F8FAFC), 12px uppercase bold labels.
- **Rows:** 48px height, white background, subtle 1px bottom border.
- **States:** Hovering over a row applies a very light blue tint (#EFF6FF) to indicate interactivity.

### Cards
- **Structure:** Defined by a 1px border. Use "Card Headers" with a bottom divider to separate titles from the content body. 
- **Usage:** Used to group patient demographics, recent lab results, or upcoming surgery schedules.

### Chips/Tags
- Small, low-saturation backgrounds with high-saturation text. For example, a "Critical" tag uses a light red background with deep red text.